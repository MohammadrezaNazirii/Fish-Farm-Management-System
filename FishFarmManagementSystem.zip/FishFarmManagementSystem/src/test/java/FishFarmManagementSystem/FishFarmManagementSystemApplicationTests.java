package FishFarmManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FishFarmManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
